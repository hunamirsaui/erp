import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: '首页',
      component: () => import('@/views/dashboard/index'),
      meta: { title: '首页', icon: 'dashboard' }
    }]
  },


  {
    path: '/UserManagement',
    component: Layout,
    redirect: '/UserManagement/user',
    name: '用户管理',
    meta: { title: '用户管理', icon: 'peoples' },
    children: [
      {
        path: 'user',
        name: '用户列表',
        component: () => import('@/views/user/index'),
        meta: { title: '用户列表', icon: 'user' }
      },
      {
        path: 'merchant',
        name: '商户号绑定',
        component: () => import('@/views/merchant/index'),
        meta: { title: '商户号绑定', icon: 'people' }
      },
      {
        path: 'banUser',
        name: '封禁账号',
        component: () => import('@/views/banUser/index'),
        meta: { title: '封禁账号', icon: 'star' }
      }
    ]
  },
  {
    path: '/combo',
    component: Layout,
    redirect: '/combo/payment',
    name: '费用设置',
    meta: { title: '费用设置', icon: 'money' },
    children: [
      {
        path: 'payment',
        name: '套餐',
        component: () => import('@/views/payment/index'),
        meta: { title: '套餐', icon: 'table' }
      },
      {
        path: 'substitution',
        name: '后台代缴',
        component: () => import('@/views/substitution/index'),
        meta: { title: '后台代缴', icon: 'tree' }
      }
    ]
  },
  {
    path: '/administrator',
    component: Layout,
    children: [
      {
        path: 'index',
        name: '管理员',
        component: () => import('@/views/administrator/index'),
        meta: { title: '管理员', icon: 'form' }
      }
    ]
  },
  {
    path: '/discount',
    component: Layout,
    children: [
      {
        path: 'index',
        name: '优惠码',
        component: () => import('@/views/discount/index'),
        meta: { title: '优惠码', icon: 'form' }
      }
    ]
  },
  {
    path: '/example',
    component: Layout,
    redirect: '/example/list',
    name: '公告',
    meta: {
      title: '公告',
      icon: 'el-icon-s-help'
    },
    children: [
      {
        path: 'create',
        component: () => import('@/views/example/create'),
        name: '创建文章',
        meta: { title: '创建文章', icon: 'edit' }
      },
      {
        path: 'edit/:id(\\d+)',
        component: () => import('@/views/example/edit'),
        name: '编辑文章',
        meta: { title: '编辑文章', noCache: true, activeMenu: '/example/list' },
        hidden: true
      },
      {
        path: 'list',
        component: () => import('@/views/example/list'),
        name: '文章列表',
        meta: { title: '文章列表', icon: 'list' }
      }
    ]
  },


  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
