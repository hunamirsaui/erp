<template>
  <el-dialog
    title="提示"
    :visible.sync="dialogVisible"
    width="30%"
    :before-close="handleClose"
  >
    <el-form
      size="mini"
      :model="ruleForm"
      :rules="rules"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="优惠码" prop="name">
        <el-input v-model="ruleForm.name"></el-input>
      </el-form-item>
      <el-form-item label="套餐名称" prop="name">
        <el-select v-model="ruleForm.region" placeholder="请选择活动区域">
          <el-option label="区域一" value="shanghai"></el-option>
          <el-option label="区域二" value="beijing"></el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="dialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="onSubmit('ruleForm')">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { transactionList } from "@/api/remote-search";
import { parseTime } from "@/utils";
export default {
  filters: {
    statusFilter(status) {
      const statusMap = {
        success: "success",
        pending: "danger",
      };
      return statusMap[status];
    },
    orderNoFilter(str) {
      return str.substring(0, 30);
    },
  },
  data() {
    return {
      ruleForm: {
        name: "",
        eamil: "",
        telegram: "",
        pass: "",
      },
      dialogVisible: false,
      rules: {
        name: [
          { required: true, message: "请输入活动名称", trigger: "blur" },
          { min: 3, max: 5, message: "长度在 3 到 5 个字符", trigger: "blur" },
        ],
        pass: [{ required: true, validator: parseTime, trigger: "blur" }],
        checkPass: [{ required: true, validator: parseTime, trigger: "blur" }],
      },
    };
  },
  created() {
    this.fetchData();
  },
  methods: {
    open(data) {
      this.dialogVisible = true;
    },
    handleClose() {},
    fetchData() {
      // transactionList().then(response => {
      //   this.list = []
      // })
    },
    onSubmit() {},
  },
};
</script>
